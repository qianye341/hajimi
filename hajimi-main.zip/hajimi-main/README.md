# 🚀 HAJIMI Gemini API Proxy

- 这是一个基于 FastAPI 构建的 Gemini API 代理，旨在提供一个简单、安全且可配置的方式来访问 Google 的 Gemini 模型。适用于在 Hugging Face Spaces 上部署，并支持openai api格式的工具集成。

## 项目采用动态更新，随时会有一些小更新同步到主仓库且会自动构建镜像，如果反馈的bug开发者说修了但是版本号没变是正常现象，~~记得勤更新镜像哦~~

# 本项目基于CC BY-NC 4.0许可开源，需遵守以下规则
- 您必须给出适当的署名，提供指向本协议的链接，并指明是否（对原作）作了修改。您可以以任何合理方式进行，但不得以任何方式暗示许可方认可您或您的使用。
- 您不得将本作品用于商业目的，包括但不限于任何形式的商业倒卖、SaaS、API 付费接口、二次销售、打包出售、收费分发或其他直接或间接盈利行为。

### 如需商业授权，请联系原作者获得书面许可。违者将承担相应法律责任。

### 感谢[@warming-afternoon](https://github.com/warming-afternoon)，[@任梓樂](https://github.com/rzline)在技术上的大力支持

###  错误自查

遇到问题请先查看以下的 **错误自查** 文档，确保已尝试按照其上的指示进行了相应的排查与处理。

- [错误自查](./wiki/error.md)
###  使用文档
- [huggingface 部署的使用文档（复活？！）（推荐，免费，手机电脑均可使用）](./wiki/huggingface.md)
- [上面看不到图的看这里](https://blog.rzline.eu.org/2025/04/29/HuggingFace%E9%83%A8%E7%BD%B2Gemini%E8%BD%AE%E8%AF%A2%E9%A1%B9%E7%9B%AEHajimi)

- [Claw Cloud部署的使用文档（推荐，免费，手机电脑均可使用）](./wiki/claw.md) 感谢[@IDeposit](https://github.com/IDeposit)编写
- [同上，看不到的看这里](https://blog.rzline.eu.org/2025/04/29/Claw%20Cloud%E9%83%A8%E7%BD%B2Gemini%E8%BD%AE%E8%AF%A2%E9%A1%B9%E7%9B%AEHajimi)

- [docker部署的使用文档（服务器自建使用）](./wiki/docker.md) 感谢[@北极星星](https://github.com/beijixingxing)编写

- [termux部署的使用文档（手机使用）](./wiki/Termux.md) 感谢[@天命不又](https://github.com/tmby)编写

- ~~[zeabur部署的使用文档(需付费)](./wiki/zeabur.md) 感谢**墨舞ink**编写~~（已过时且暂时无人更新，欢迎提交pull requests）

- [vertex模式的使用文档](./wiki/vertex.md)

###  更新日志
* v0.2.5
   * 警告，本次新增了openai依赖库，非容器部署请拉取安装依赖库
   * 首发适配vertex快速模式，在配置key后，访问支持快速模式的模型时，将首先使用快速模式的key访问
   * 快速模式仅支持gemini-2.0-flash-001,gemini-2.0-flash-lite-001,gemini-2.5-pro-preview-03-25,gemini-2.5-flash-preview-04-17
   * 更新vertex模式ui，前端界面现在可以开启关闭假流式，快速模式与替换快速模式key
   * 新增环境变量`VERTEX_EXPRESS_API_KEY`，为快速模式key
   * 修复若干bug，提高系统稳定性

* v0.2.4
   * 为vertex模式适配gemini-2.5-pro-preview-05-06
   * 修复负载均衡模式bug
   * 优化统计相关计算，占用性能更少
   * 修复若干bug，提高系统稳定性

* 历史版本更新日志请查看[update](./update.md)

## ✨ 主要功能：

### 🔑 API 密钥轮询和管理

### 📑 模型列表接口

### 💬 聊天补全接口：

*   提供 `/v1/chat/completions` 接口，支持流式和非流式响应，支持函数调用，与 OpenAI API 格式兼容。
*   支持的输入内容: 文本、文件、图像
*   自动将 OpenAI 格式的请求转换为 Gemini 格式。

### 🔒 密码保护（可选）：

*   通过 `PASSWORD` 环境变量设置密码。
*   提供默认密码 `"123"`。

### 🚦 速率限制和防滥用：

*   通过环境变量自定义限制：
    *   `MAX_REQUESTS_PER_MINUTE`：每分钟最大请求数（默认 30）。
    *   `MAX_REQUESTS_PER_DAY_PER_IP`：每天每个 IP 最大请求数（默认 600）。
*   超过速率限制时返回 429 错误。

### 🧩 服务兼容

*   提供的接口与 OpenAI API 格式兼容,便于接入各种服务

## ⚠️ 注意事项：

*   **强烈建议在生产环境中设置 `PASSWORD` 环境变量，并使用强密码。**
*   根据你的使用情况调整速率限制相关的环境变量。
*   确保你的 Gemini API 密钥具有足够的配额。


## ⚙️ 特色功能：

### 🎭 假流式传输

*   **作用：** 解决部分网络环境下客户端通过非流式请求 Gemini 时可能遇到的断连问题。**默认开启**。

*   **原理简述：** 当客户端请求流式响应时，本代理会每隔一段时间向客户端发出一个空信息以维持连接，同时在后台向 Gemini 发起一个完整的、非流式的请求。等 Gemini 返回完整响应后，再一次性将响应发回给客户端。

*   **如何配置：**
    *   `FAKE_STREAMING`: 设置为 `true` (默认) 开启，设置为 `false` 关闭。
    *   `FAKE_STREAMING_INTERVAL`: 设置发送空信息的间隔时间（秒），默认为 `1`。

*   **注意：** 如果想使用真的流式请求，请**关闭**该功能

### ⚡ 并发与缓存

*   **作用：** 允许您为用户的单次提问同时向 Gemini 发送多个请求，并将额外的成功响应缓存起来，用于后续重新生成回复。

*   **注意：** 此功能**默认关闭** 。只有当您将并发数设置为 2 或以上时，缓存才会生效。缓存匹配要求提问的上下文与被缓存的问题**完全一致**（包括标点符号）。此外，该模式目前仅支持非流式及假流式传输

*   **配置与说明：**
    *   `CONCURRENT_REQUESTS`: 设置每次用户提问时，同时向 Gemini 发送的请求数量。默认为 `1` (即关闭并发和缓存)。
    *   `INCREASE_CONCURRENT_ON_FAILURE`: 当所有并发请求都失败时，临时增加多少并发数再次尝试。默认为 `0`。
    *   `MAX_CONCURRENT_REQUESTS`: 允许的最大并发请求数。默认为 `3`。
    *   `CACHE_EXPIRY_TIME`: 缓存的有效时间（秒），默认 `21600` (6小时)。
    *   `MAX_CACHE_ENTRIES`: 最多缓存多少条响应，默认 `500`。
    *   `PRECISE_CACHE`: 是否使用用户的全部消息，而不是最后八条来计算缓存键。默认为 `false`。
    
    **Q: 新版本增加的并发缓存功能会增加 gemini 配额的使用量吗？**
   
    **A: 不会**。因为默认情况下该功能是关闭的。只有当你主动将并发数 `CONCURRENT_REQUESTS` 设置为大于 1 的数值时，才会实际发起并发请求，这才会消耗更多配额。
   
    **Q: 如何使用并发缓存功能？**
   
    **A:** 修改环境变量 `CONCURRENT_REQUESTS`，使其等于你想在一次用户提问中同时向 Gemini 发送的请求数量（例如设置为 `3`）。这样设置后，如果一次并发请求中收到了多个成功的响应，除了第一个返回给用户外，其他的就会被缓存起来。

### 🎭 伪装信息

*   **作用：** 在发送给 Gemini 的消息中添加一段随机生成的、无意义的字符串，用于“伪装”请求，可能有助于防止被识别为自动化程序。**默认开启**。

*   **如何配置：**
    *   `RANDOM_STRING`: 设置为 `true` (默认) 开启，设置为 `false` 关闭。
    *   `RANDOM_STRING_LENGTH`: 设置随机字符串的长度，默认为 `5`。

*   **注意：** 如果使用非 SillyTavern 的其余客户端 (例如 cherryStudio )，请**关闭**该功能

### 🌐 联网模式

*   **作用：** 让 Gemini 模型能够利用搜索工具进行联网搜索，以回答需要最新信息或超出其知识库范围的问题。

*   **如何使用：**
    1.  将环境变量 `SEARCH_MODE` (默认为 `false`) 设置为 `true` 来启用此功能。
    2.  在客户端请求时，选择模型名称带有 `-search` 后缀的模型（例如 `gemini-2.5-pro-exp-search`，具体可用模型请通过 `/v1/models` 接口查询）。

*   **如何配置：**
    *   `SEARCH_MODE`: 设置为 `true` 启用，`false` 关闭。
    *   `SEARCH_PROMPT`: 当使用联网模式时，附加给模型的提示词，引导它使用搜索工具。默认为 `（使用搜索工具联网搜索，需要在content中结合搜索内容）`。

